<?php

function city(){
    $connect = mysqli_connect("localhost","root","","dropdown");
    $output = '';
    $sql = "SELECT * from countries";
    $result = mysqli_query($connect, $sql);

    while($row = mysqli_fetch_array($result)){
        $output .= '<option value="'.$row["country_id"].'">'.$row["country_name"].'</option>';
    }

    return $output;
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"> </script>
<script src="jquery-3.4.1.min.js"></script>
</head>
<body>
    <h1></h1>
    <div class="container">
        <div class="form-group">
        <select name="select country" id="country" class="form-control">
        <option value="">Country</option>
        <?php echo city(); ?>
        </select>
        </div>
        

         <select name="state" id="state" >
        <option value="">State</option>
        </select>
        
        <select name="Cities" id="cities" >
        <option value="">cities</option>
        </select>
        
</body>
</html>

<script>
$(document).ready(function(){
    $('#country').change(function(){
        var country_id = $(this).val();
        $.ajax({
            url:"tate.php",
            method:"POST",
            data:{countrywiseState:country_id},
            dataType:"text",
            success:function(data)
            {
                $('#state').html(data);
            }
        });
    });
});

$(document).ready(function(){
    $('#state').change(function(){
        var state_id = $(this).val();
        $.ajax({
            url:"tate.php",
            method:"POST",
            data:{statewisecities:state_id},
            dataType:"text",
            success:function(data)
            {
                $('#cities').html(data);
            }
        });
    });
});
</script>


